#ifndef HELLO_H
#define HELLO_H

/* hello */
const char *gethellostr();

#endif
