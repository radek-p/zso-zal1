#include <stdio.h>
#include "hello.h"

void hello() {
	printf("Hello, %s!\n", gethellostr());
}
