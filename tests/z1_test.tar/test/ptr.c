extern int x[];
int *px0 = &x[0];
int *px1 = &x[1];
