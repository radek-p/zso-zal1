extern void lazy();

void call_lazy() {
	lazy();
}
